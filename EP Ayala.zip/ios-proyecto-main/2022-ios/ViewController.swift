//
//  ViewController.swift
//  2022-ios
//
//  Created by user194451 on 5/19/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

 
    
}

